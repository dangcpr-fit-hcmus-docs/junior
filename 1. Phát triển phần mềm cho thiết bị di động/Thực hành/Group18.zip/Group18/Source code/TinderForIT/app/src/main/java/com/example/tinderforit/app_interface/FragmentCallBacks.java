package com.example.tinderforit.app_interface;

import java.util.List;

public interface FragmentCallBacks {
    public void onMsgFromMainToFragment(String strValue);
}
