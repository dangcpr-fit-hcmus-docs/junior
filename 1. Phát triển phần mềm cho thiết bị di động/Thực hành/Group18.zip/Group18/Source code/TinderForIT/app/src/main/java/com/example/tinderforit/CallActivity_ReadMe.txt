Cách thực hiện cuộc gọi hay nhận cuộc gọi sau khi nhấn biểu tượng Phone call:
- Bấm "Connect" để kết nối với server điều khiển cuộc gọi.
- Nhấn vào "Make call":
    + Nếu như có 1 người khác gọi tới, 2 màn hình video sẽ tự động xuất hiện
    + Nếu như thực hiện 1 cuộc gọi tới 1 người, khi nào đối phương nhấn "Make call" thì 2 màn hình video sẽ tự động xuất hiện để 2 người thực hiện cuộc gọi.
- Để kết thúc cuộc gọi, nhấn "Make call" một lần nữa (1 trong 2 bên ngừng cuộc gọi thì bên còn lại cũng ngừng theo),