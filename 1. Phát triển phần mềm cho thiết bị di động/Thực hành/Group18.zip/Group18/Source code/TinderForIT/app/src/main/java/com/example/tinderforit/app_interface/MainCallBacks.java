package com.example.tinderforit.app_interface;

public interface MainCallBacks {
    public void onMsgFromFragToMain (String sender, String strValue);
}

