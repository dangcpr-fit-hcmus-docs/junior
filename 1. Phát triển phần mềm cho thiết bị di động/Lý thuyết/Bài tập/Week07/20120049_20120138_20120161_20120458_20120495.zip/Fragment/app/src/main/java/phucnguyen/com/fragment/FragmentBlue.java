package phucnguyen.com.fragment;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import java.io.File;

public class FragmentBlue extends Fragment implements FragmentCallbacks {
    MainActivity main;
    Context context = null;
    ListView listView;
    String message ="";
    TextView txtBlue;
    Integer current_position = -1;

    SQLiteDatabase db_1;


    private String[] items = null;
    private Integer[] thumbnails = null;

    public static FragmentBlue newInstance(String strArg) {
        FragmentBlue fragment = new FragmentBlue();
        Bundle args = new Bundle();
        args.putString("strArg1", strArg);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            context = getActivity(); // use this reference to invoke main callbacks
            main = (MainActivity) getActivity();
        }
        catch (IllegalStateException e) {
            throw new IllegalStateException("MainActivity must implement callbacks");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        File storagePath = main.getApplication().getFilesDir();
        String myDbPath = storagePath + "/" + "myClass";

        db_1 = SQLiteDatabase.openDatabase(myDbPath, null, SQLiteDatabase.CREATE_IF_NECESSARY);
        Cursor c1 = db_1.rawQuery("select count(*) from STUDENT",null);
        c1.moveToPosition(0);
        int n = c1.getInt(0);

        items = new String[n];
        thumbnails = new Integer[n];

        for(int i = 0;i<n;++i) {
            items[i] = getStudentId(i);
            thumbnails[i] = getPic(i);
        }

        // inflate layout
        LinearLayout layout_blue = (LinearLayout) inflater.inflate(R.layout.layout_blue,null);

        // plumbing textview listview
        txtBlue = (TextView) layout_blue.findViewById(R.id.textView1Blue);
        listView = (ListView) layout_blue.findViewById(R.id.listView1Blue);

        // create list view
        CustomLabelAdapter adapter = new CustomLabelAdapter(context, R.layout.custom_row_icon_label, items, thumbnails);
        listView.setAdapter(adapter);

        // show listview from the top
        listView.setSelection(0); listView.smoothScrollToPosition(0);

        // set on Click
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                current_position = position;
                sendMessageToRedFrag();
                listView.smoothScrollToPosition(current_position);
                txtBlue.setText("Mã số: " + getStudentId(position));
            }
        });
        // do this for each row (ViewHolder-Pattern could be used for better performance!)

        db_1.close();
        return layout_blue;
    }

    @Override
    public void onMsgFromMainToFragment(String strValue) {
        if ("First" == strValue && current_position != -1) {
            current_position = 0;
            sendMessageToRedFrag();
            listView.setItemChecked(current_position,true);
            listView.smoothScrollToPosition(current_position);

        } else if ("Last" == strValue && current_position != -1) {
            current_position = items.length - 1;
            sendMessageToRedFrag();
            listView.setItemChecked(current_position,true);
            listView.smoothScrollToPosition(current_position);

        } else if ("Next" == strValue && current_position != -1) {

            if (current_position == items.length - 1) {
                current_position = 0;
            }
            else {
                current_position += 1;
            }
            sendMessageToRedFrag();
            listView.setItemChecked(current_position,true);
            listView.smoothScrollToPosition(current_position);

        } else if ("Previous" == strValue && current_position != -1) {
            if (current_position == 0) {
                current_position = items.length - 1;
            }
            else {
                current_position  -= 1;
            }
            sendMessageToRedFrag();
            listView.setItemChecked(current_position,true);
            listView.smoothScrollToPosition(current_position);
        }
    }

    private void sendMessageToRedFrag() {
        Integer maxIndex = items.length - 1;
        message = maxIndex + "-" + current_position + "-" + getStudentId(current_position) + "-" + "Họ tên: " + getStudentName(current_position) + "\nLớp: " + getClass(current_position)
                + "\nĐiểm trung bình: " + String.valueOf(getGrade(current_position));
        main.onMsgFromFragToMain("BLUE-FRAG", message);
    }

    private String getStudentId(int index) {
        File storagePath = main.getApplication().getFilesDir();
        String myDbPath = storagePath + "/" + "myClass";
        db_1 = SQLiteDatabase.openDatabase(myDbPath, null, SQLiteDatabase.CREATE_IF_NECESSARY);

        String sql = "select * from STUDENT";
        Cursor c1 = db_1.rawQuery(sql, null);

        c1.moveToPosition(0);
        for(int i = 0;i<index;++i) {
            c1.moveToNext();
        }

        String temp = c1.getString(0);

        db_1.close();
        return temp;
    }

    private String getStudentName(int index) {
        File storagePath = main.getApplication().getFilesDir();
        String myDbPath = storagePath + "/" + "myClass";
        db_1 = SQLiteDatabase.openDatabase(myDbPath, null, SQLiteDatabase.CREATE_IF_NECESSARY);

        String sql = "select * from STUDENT";
        Cursor c1 = db_1.rawQuery(sql, null);

        c1.moveToPosition(0);
        for(int i = 0;i<index;++i) {
            c1.moveToNext();
        }

        String temp = c1.getString(1);
        db_1.close();
        return temp;
    }

    private float getGrade(int index) {
        File storagePath = main.getApplication().getFilesDir();
        String myDbPath = storagePath + "/" + "myClass";
        db_1 = SQLiteDatabase.openDatabase(myDbPath, null, SQLiteDatabase.CREATE_IF_NECESSARY);

        String sql = "select * from STUDENT";
        Cursor c1 = db_1.rawQuery(sql, null);

        c1.moveToPosition(0);
        for(int i = 0;i<index;++i) {
            c1.moveToNext();
        }

        float temp = c1.getFloat(2);
        db_1.close();
        return temp;
    }

    private String getClass(int index) {
        File storagePath = main.getApplication().getFilesDir();
        String myDbPath = storagePath + "/" + "myClass";
        db_1 = SQLiteDatabase.openDatabase(myDbPath, null, SQLiteDatabase.CREATE_IF_NECESSARY);

        String sql = "select * from STUDENT";
        Cursor c1 = db_1.rawQuery(sql, null);

        c1.moveToPosition(0);
        for(int i = 0;i<index;++i) {
            c1.moveToNext();
        }

        String temp = c1.getString(3);
        db_1.close();
        return temp;
    }

    private Integer getPic(int index) {
        File storagePath = main.getApplication().getFilesDir();
        String myDbPath = storagePath + "/" + "myClass";
        db_1 = SQLiteDatabase.openDatabase(myDbPath, null, SQLiteDatabase.CREATE_IF_NECESSARY);

        String sql = "select * from STUDENT";
        Cursor c1 = db_1.rawQuery(sql, null);

        c1.moveToPosition(0);
        for(int i = 0;i<index;++i) {
            c1.moveToNext();
        }

        Integer temp = c1.getInt(4);
        db_1.close();
        return temp;
    }
}
