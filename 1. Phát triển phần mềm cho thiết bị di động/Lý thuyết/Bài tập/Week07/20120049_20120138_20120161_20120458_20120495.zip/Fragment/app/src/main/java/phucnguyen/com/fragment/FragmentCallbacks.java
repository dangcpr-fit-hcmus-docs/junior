package phucnguyen.com.fragment;

public interface FragmentCallbacks {
    public void onMsgFromMainToFragment(String strValue);
}
