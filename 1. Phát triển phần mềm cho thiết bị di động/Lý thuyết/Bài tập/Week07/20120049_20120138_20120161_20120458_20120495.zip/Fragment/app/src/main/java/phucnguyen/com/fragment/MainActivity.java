package phucnguyen.com.fragment;

import static android.database.sqlite.SQLiteDatabase.CREATE_IF_NECESSARY;
import static android.os.Build.ID;

import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.io.File;

public class MainActivity extends FragmentActivity implements MainCallbacks{
    FragmentTransaction ft;
    FragmentRed redFragment;
    FragmentBlue blueFragment;

    SQLiteDatabase db;

    int a = R.drawable.man1;

    private static final String KEY_ID = "ID";
    private static final String KEY_NAME = "name";
    private static final String KEY_GRADES = "grades";
    private static final String KEY_CLASS = "class";
    private static final String KEY_PIC = "pic";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        File storagePath = getApplication().getFilesDir();
        String myDbPath = storagePath + "/" + "myClass";

        try {
            deleteDatabase(myDbPath);

            db = SQLiteDatabase.openDatabase(myDbPath, null, CREATE_IF_NECESSARY);
            db.execSQL("create table if not exists STUDENT (ID text PRIMARY KEY, name text, grades real, class text, pic int); ");

            ContentValues values = new ContentValues();

            values.put(KEY_ID,"A1_5245"); values.put(KEY_NAME,"Nguyễn Hữu Phúc");
            values.put(KEY_GRADES,8); values.put(KEY_CLASS,"A1"); values.put(KEY_PIC,R.drawable.man1);
            db.insert("STUDENT",null,values);

            values.put(KEY_ID,"A2_3862"); values.put(KEY_NAME,"Nguyễn Khánh Linh");
            values.put(KEY_GRADES,9.5); values.put(KEY_CLASS,"A2"); values.put(KEY_PIC,R.drawable.wman3);
            db.insert("STUDENT",null,values);

            values.put(KEY_ID,"A3_4820"); values.put(KEY_NAME,"Lê Thành Nam");
            values.put(KEY_GRADES,9); values.put(KEY_CLASS,"A3"); values.put(KEY_PIC,R.drawable.man2);
            db.insert("STUDENT",null,values);

            values.put(KEY_ID,"A4_9472"); values.put(KEY_NAME,"Lê Xuân Huy");
            values.put(KEY_GRADES,8); values.put(KEY_CLASS,"A4"); values.put(KEY_PIC,R.drawable.man1);
            db.insert("STUDENT",null,values);

            values.put(KEY_ID,"A1_4346"); values.put(KEY_NAME,"Hoàng Thu Hồng");
            values.put(KEY_GRADES,8.5); values.put(KEY_CLASS,"A1"); values.put(KEY_PIC,R.drawable.wman4);
            db.insert("STUDENT",null,values);

            values.put(KEY_ID,"A3_2536"); values.put(KEY_NAME,"Hồ Sĩ Đức");
            values.put(KEY_GRADES,7.5); values.put(KEY_CLASS,"A3"); values.put(KEY_PIC,R.drawable.man1);
            db.insert("STUDENT",null,values);

            values.put(KEY_ID,"A2_7584"); values.put(KEY_NAME,"Nguyễn Hải Đăng");
            values.put(KEY_GRADES,9.5); values.put(KEY_CLASS,"A2"); values.put(KEY_PIC,R.drawable.man2);
            db.insert("STUDENT",null,values);

            values.put(KEY_ID,"A1_7583"); values.put(KEY_NAME,"Nguyễn Hữu Hậu");
            values.put(KEY_GRADES,8.5); values.put(KEY_CLASS,"A1"); values.put(KEY_PIC,R.drawable.man1);
            db.insert("STUDENT",null,values);

            values.put(KEY_ID,"A4_6473"); values.put(KEY_NAME,"Lê Thị Nữ");
            values.put(KEY_GRADES,10); values.put(KEY_CLASS,"A4"); values.put(KEY_PIC,R.drawable.wman3);
            db.insert("STUDENT",null,values);

            values.put(KEY_ID,"A3_6468"); values.put(KEY_NAME,"Hồ Ngọc Nam");
            values.put(KEY_GRADES,7); values.put(KEY_CLASS,"A3"); values.put(KEY_PIC,R.drawable.man1);
            db.insert("STUDENT",null,values);

            // create BLUE fragment - show it
            ft = getSupportFragmentManager().beginTransaction();
            blueFragment = FragmentBlue.newInstance("first-blue");
            ft.replace(R.id.main_holder_blue, blueFragment);
            ft.commit();

            // create Red fragment - show it
            ft = getSupportFragmentManager().beginTransaction();
            redFragment = FragmentRed.newInstance("first-red");
            ft.replace(R.id.main_holder_red, redFragment);
            ft.commit();

            db.close();
        }
        catch (SQLiteException e) { Toast.makeText(this, "Error!", Toast.LENGTH_SHORT).show(); }
    }

    // hàm viết ở main, được gọi ở fragment red và blue -> gởi thông tin về main
    @Override
    public void onMsgFromFragToMain(String sender, String strValue) {

        if (sender.equals("RED-FRAG")){
            try {
                blueFragment.onMsgFromMainToFragment(strValue);
            }
            catch (Exception e) {
                Log.e("ERROR", "onStrFromFragToMain" + e.getMessage());
            }
        }
        if (sender.equals("BLUE-FRAG")){
            try {
                redFragment.onMsgFromMainToFragment(strValue);
            }
            catch (Exception e) {
                Log.e("ERROR", "onStrFromFragToMain" + e.getMessage());
            }
        }
    }
}