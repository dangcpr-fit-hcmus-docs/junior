package com.example.nprproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    ImageButton npr, thanhnien, vnexpress, vietnamnews;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        npr = findViewById(R.id.npr_article);
        thanhnien = findViewById(R.id.thanhnien_article);
        vnexpress = findViewById(R.id.vnexpress_article);
        vietnamnews = findViewById(R.id.vietnamnews_article);

        npr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, NPRArticleActivity.class);
                startActivity(intent);
            }
        });

        thanhnien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ThanhNienArticleActivity.class);
                startActivity(intent);
            }
        });

        vnexpress.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, VNEpressArticleActivity.class);
                startActivity(intent);
            }
        });

        vietnamnews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, VietNamNewsArticleActivity.class);
                startActivity(intent);
            }
        });
    }
}