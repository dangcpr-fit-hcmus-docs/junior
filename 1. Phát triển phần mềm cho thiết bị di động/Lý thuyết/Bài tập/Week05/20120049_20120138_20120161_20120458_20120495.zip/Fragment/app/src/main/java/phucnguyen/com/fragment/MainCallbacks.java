package phucnguyen.com.fragment;

public interface MainCallbacks {
    public void onMsgFromFragToMain (String sender, String strValue);
}
