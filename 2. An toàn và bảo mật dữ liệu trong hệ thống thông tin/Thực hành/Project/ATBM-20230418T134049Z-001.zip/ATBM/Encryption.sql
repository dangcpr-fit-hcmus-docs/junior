﻿----------------- MÃ HOÁ -----------------
-- Mã hoá thông tin dị ứng thuốc của bệnh nhân, sử dụng key mã hoá là cmnd

-- Tạo package hỗ trợ mã hoá - giải mã
CREATE OR REPLACE PACKAGE ENCRYPT_DECRYPT
AS
  FUNCTION ENCRYPT_BENHNHAN(p_in IN NVARCHAR2,p_key IN CHAR) 
    RETURN RAW DETERMINISTIC;
  FUNCTION DECRYPT_BENHNHAN(p_in IN RAW,p_key IN CHAR) 
    RETURN NVARCHAR2 DETERMINISTIC;
END ENCRYPT_DECRYPT;
/
-- Cài đặt các function trong package trên
CREATE OR REPLACE PACKAGE BODY ENCRYPT_DECRYPT  
IS 
  encryption_type PLS_INTEGER :=
							 DBMS_CRYPTO.ENCRYPT_DES
							+DBMS_CRYPTO.CHAIN_CBC
							+DBMS_CRYPTO.PAD_PKCS5;

  FUNCTION ENCRYPT_BENHNHAN(p_in IN NVARCHAR2,p_key IN CHAR) 
    RETURN RAW DETERMINISTIC
  IS
  	encrypted_raw RAW(2000);
  BEGIN
       encrypted_raw := dbms_crypto.encrypt(
          src => utl_raw.cast_to_raw(p_in),
          typ => encryption_type,
          key => utl_raw.cast_to_raw(p_key)
      );
      RETURN encrypted_raw;
  END ENCRYPT_BENHNHAN;
  
  FUNCTION DECRYPT_BENHNHAN(p_in IN RAW,p_key IN CHAR) 
    RETURN NVARCHAR2 DETERMINISTIC
  IS
    decrypted_raw raw(2000);
  BEGIN
       decrypted_raw := dbms_crypto.decrypt(
          src => p_in,
          typ => encryption_type,
          key => utl_raw.cast_to_raw(p_key)
      );     
      return utl_raw.CAST_TO_NVARCHAR2(decrypted_raw);
  END DECRYPT_BENHNHAN;
END ENCRYPT_DECRYPT;
/

-- Mã hoá tất cả thông tin dị ứng thuốc trong bảng bệnh nhân
UPDATE benhnhan b1
SET DIUNGTHUOC = (SELECT ENCRYPT_DECRYPT.ENCRYPT_BENHNHAN(DIUNGTHUOC, CMND) 
                  FROM BENHNHAN b2 WHERE b1.mabn = b2.mabn);
COMMIT;
/

-- Tự động mã hoá thông tin bệnh nhân khi thêm, sửa bệnh nhân
CREATE OR REPLACE TRIGGER AUTO_ENCRYPTED_BENHNHAN
  BEFORE INSERT OR UPDATE
  ON QLTT.BENHNHAN
  FOR EACH ROW
DECLARE
BEGIN
  :NEW.DIUNGTHUOC := ENCRYPT_DECRYPT.ENCRYPT_BENHNHAN(:new.DIUNGTHUOC, :new.CMND);
END;


-- Cấp quyền mã hoá, giải mã thông tin bệnh nhân cho bác sĩ, bệnh nhân
GRANT EXECUTE ON QLTT.ENCRYPT_DECRYPT TO BAC_SI;
GRANT EXECUTE ON QLTT.ENCRYPT_DECRYPT TO BENH_NHAN;

-- Kiểm tra 
SELECT tenbn, diungthuoc,QLTT.ENCRYPT_DECRYPT.DECRYPT_BENHNHAN(diungthuoc, CMND) AS diungthuoc_giaima 
FROM QLTT.BENHNHAN;