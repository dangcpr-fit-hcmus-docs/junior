﻿-- Nhân viên (trừ DBA và role THANH_TRA chỉ có thể xem thông tin bản thân

CREATE OR REPLACE FUNCTION QLTT.NV_XEM_SUA_TT_CA_NHAN(   
   P_SCHEMA IN VARCHAR2 DEFAULT NULL,
   P_OBJECT IN VARCHAR2 DEFAULT NULL
) 
RETURN VARCHAR2 
AS
  USERNAME VARCHAR2(128);
  USERROLE VARCHAR2(128);
BEGIN
  -- Lấy username của user hiện tại
  USERNAME := SYS_CONTEXT('userenv', 'SESSION_USER');
  
  IF USERNAME = 'QLTT' 
    THEN RETURN '';
  END IF;

  SELECT GRANTED_ROLE INTO USERROLE FROM DBA_ROLE_PRIVS WHERE GRANTEE = ''||USERNAME||'';

  IF 'THANH_TRA' IN (USERROLE) THEN
    RETURN '';
  ELSE
    RETURN 'CMND ='||USERNAME;
  END IF;
END;



BEGIN dbms_rls.add_policy 
(object_schema =>'QLTT',
object_name => 'NHANVIEN',
policy_name => 'POLICY_NV_XEM_SUA_TT_CA_NHAN',
function_schema => 'QLTT',
policy_function => 'NV_XEM_SUA_TT_CA_NHAN',
statement_types => 'SELECT, UPDATE',
update_check => TRUE);
END;



-- Bệnh nhân chỉ có thể xem, sửa thông tin của bản thân
CREATE OR REPLACE FUNCTION QLTT.BN_XEM_SUA_TT_CA_NHAN(   
   P_SCHEMA IN VARCHAR2 DEFAULT NULL,
   P_OBJECT IN VARCHAR2 DEFAULT NULL
) 
RETURN VARCHAR2 
AS
  USERNAME VARCHAR2(128);
  USERROLE VARCHAR2(128);
BEGIN
  -- Lấy username của user hiện tại
  USERNAME := SYS_CONTEXT('userenv', 'SESSION_USER');
  
  IF USERNAME = 'QLTT' 
    THEN RETURN '';
  END IF;
  
  SELECT GRANTED_ROLE INTO USERROLE FROM DBA_ROLE_PRIVS WHERE GRANTEE = ''||USERNAME||'';

  IF 'BENH_NHAN' IN (USERROLE) THEN
    RETURN 'CMND ='||USERNAME;
  ELSE
    RETURN '1=1';
  END IF;
END;


BEGIN dbms_rls.add_policy 
(object_schema =>'QLTT',
object_name => 'BENHNHAN',
policy_name => 'POLICY_BN_XEM_SUA_TT_CA_NHAN',
function_schema => 'QLTT',
policy_function => 'BN_XEM_SUA_TT_CA_NHAN',
statement_types => 'SELECT, UPDATE',
update_check => TRUE);
END;
