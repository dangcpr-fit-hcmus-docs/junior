﻿CONNECT QLTT/admin123@XE;

--Kích hoạt việc ghi nhật ký toàn hệ thống.
-- enable audit
alter system set audit_trail=DB scope=spfile;




SELECT * FROM BENHNHAN b

--Giám sát việc thêm xoá sửa trên bảng bệnh nhân, hồ sơ bệnh án 
audit insert,update, delete on QLTT.BENHNHAN by access;
audit insert,update, delete on QLTT.HSBA by access;



SELECT * FROM THONGBAO t

SELECT * FROM BENHNHAN b

--giám sát khi insert thông báo thành công
AUDIT INSERT ON QLTT.THONGBAO BY ACCESS WHENEVER SUCCESSFUL;



SELECT * FROM DBA_USERS;
SELECT * FROM THONGBAO t

SELECT * FROM BENHNHAN
SELECT * FROM HSBA_DV

select * from DBA_AUDIT_POLICIES;

-- TẠO 1 POLICY GIÁM SÁT INSERT TRÊN HSBA 
CREATE AUDIT POLICY In_HSBA
ACTIONS INSERT ON QLTT.HSBA

-- GIÁM SÁT TẤT CẢ HỒ SƠ BỆNH ÁN DỊCH VỤ MÀ CÓ MÃ DỊCH VỤ =1 
-- FGA
--Thực hiện Fine-grained Audit một số tình huống và cho kịch bản minh họa.
BEGIN
  DBMS_FGA.add_policy(

    object_schema   => 'QLTT',
    object_name     => 'HSBA_DV',
    policy_name     => 'FGA_HSBA_DV',
    AUDIT_CONDITION => 'MADV=1',
    statement_types => 'SELECT, INSERT,UPDATE,DELETE'
    );
END;

select * from DBA_AUDIT_POLICIES;
SELECT * FROM SYS.ALL_AUDIT_POLICIES aap




----Kiem tra ket qua Audit:Kiểm tra dữ liệu nhật ký hệ thống.
SELECT username,extended_timestamp,obj_name,action_name FROM dba_audit_trail;








CONNECT QLTT/admin123@XE;
