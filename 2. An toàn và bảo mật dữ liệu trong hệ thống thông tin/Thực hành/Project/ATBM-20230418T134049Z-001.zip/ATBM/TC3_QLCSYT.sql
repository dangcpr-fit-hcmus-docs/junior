﻿-- Tạo function cho QL_CSYT chỉ có thể thêm, xoá HSBA thuộc CSYT của nhân viên đó
CREATE OR REPLACE FUNCTION QLTT.QLCSYT_THEM_XOA_HSBA(   
   P_SCHEMA IN VARCHAR2 DEFAULT NULL,
   P_OBJECT IN VARCHAR2 DEFAULT NULL
) 
RETURN VARCHAR2 
AS
  USERNAME VARCHAR2(128);
  USERROLE VARCHAR2(128);
  USER_CSYT INT;
BEGIN
  -- Lấy username của user hiện tại
  USERNAME := SYS_CONTEXT('userenv', 'SESSION_USER');
  
  IF USERNAME = 'QLTT' 
    THEN RETURN '';
  END IF;

  -- Lấy role của user hiện tại
  SELECT GRANTED_ROLE INTO USERROLE FROM DBA_ROLE_PRIVS WHERE GRANTEE = ''||USERNAME||'';

  IF 'QL_CSYT' IN (USERROLE) THEN
    SELECT CSYT INTO USER_CSYT FROM NHANVIEN WHERE CMND = USERNAME;
    RETURN 'MACSYT =' || USER_CSYT;
  ELSE
    RETURN '0=1';
  END IF;
END;



BEGIN dbms_rls.add_policy 
(object_schema =>'QLTT',
object_name => 'HSBA',
policy_name => 'POLICY_QLCSYT_THEM_XOA_HSBA',
function_schema => 'QLTT',
policy_function => 'QLCSYT_THEM_XOA_HSBA',
statement_types => 'INSERT, DELETE',
update_check => TRUE);
END;


--BEGIN dbms_rls.drop_policy 
--(object_schema =>'QLTT',
--object_name => 'HSBA',
--policy_name => 'POLICY_QLCSYT_THEM_XOA_HSBA');
--END;


-----------------------------------------

-- Tạo function cho QL_CSYT chỉ có thể thêm, xoá HSBA_DV thuộc CSYT của nhân viên đó
CREATE OR REPLACE FUNCTION QLTT.QLCSYT_THEM_XOA_HSBADV(   
   P_SCHEMA IN VARCHAR2 DEFAULT NULL,
   P_OBJECT IN VARCHAR2 DEFAULT NULL
) 
RETURN VARCHAR2 
AS
  USERNAME VARCHAR2(128);
  USERROLE VARCHAR2(128);
  USER_CSYT INT;
BEGIN
  -- Lấy username của user hiện tại
  USERNAME := SYS_CONTEXT('userenv', 'SESSION_USER');
  
  IF USERNAME = 'QLTT' 
    THEN RETURN '';
  END IF;

  -- Lấy role của user hiện tại
  SELECT GRANTED_ROLE INTO USERROLE FROM DBA_ROLE_PRIVS WHERE GRANTEE = ''||USERNAME||'';

  IF 'QL_CSYT' IN (USERROLE) THEN
    SELECT CSYT INTO USER_CSYT FROM NHANVIEN WHERE CMND = USERNAME;
    RETURN 'MAHSBA IN (SELECT MAHSBA FROM HSBA WHERE MACSYT = ' || USER_CSYT ||')';
  ELSE
    RETURN '0=1';
  END IF;
END;



BEGIN dbms_rls.add_policy 
(object_schema =>'QLTT',
object_name => 'HSBA_DV',
policy_name => 'POLICY_QLCSYT_THEM_XOA_HSBADV',
function_schema => 'QLTT',
policy_function => 'QLCSYT_THEM_XOA_HSBADV',
statement_types => 'INSERT, DELETE',
update_check => TRUE);
END;


--BEGIN dbms_rls.drop_policy 
--(object_schema =>'QLTT',
--object_name => 'HSBA_DV',
--policy_name => 'POLICY_QLCSYT_THEM_XOA_HSBADV');
--END;


SELECT * FROM QLTT.BENHNHAN;

SELECT PRIVILEGE, TABLE_NAME FROM ROLE_TAB_PRIVS WHERE ROLE IN (SELECT * FROM SESSION_ROLES);

 SELECT * FROM DBA_ROLE_PRIVS WHERE GRANTEE = '232630930';

 SELECT * FROM DBA_ROLE_PRIVS WHERE GRANTEE = '909551314';

 SELECT * FROM DBA_ROLE_PRIVS WHERE GRANTEd_ROLE = 'THANH_TRA';

SELECT * FROM NHANVIEN WHERE VAITRO=N'Thanh tra';