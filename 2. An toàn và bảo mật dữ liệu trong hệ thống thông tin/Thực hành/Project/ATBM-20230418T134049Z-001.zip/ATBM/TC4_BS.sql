﻿-- Tạo function cho QL_CSYT chỉ có thể thêm, xoá HSBA thuộc CSYT của nhân viên đó
CREATE OR REPLACE FUNCTION QLTT.BS_XEM_CT_HSBA(   
   P_SCHEMA IN VARCHAR2 DEFAULT NULL,
   P_OBJECT IN VARCHAR2 DEFAULT NULL
) 
RETURN VARCHAR2 
AS
  USERNAME VARCHAR2(128);
  USERROLE VARCHAR2(128);
  MA_BS INT;
BEGIN
  -- Lấy username của user hiện tại
  USERNAME := SYS_CONTEXT('userenv', 'SESSION_USER');
  
  IF USERNAME = 'QLTT' 
    THEN RETURN '';
  END IF;

  -- Lấy role của user hiện tại
  SELECT GRANTED_ROLE INTO USERROLE FROM DBA_ROLE_PRIVS WHERE GRANTEE = ''||USERNAME||'';

  IF 'BAC_SI' IN (USERROLE) THEN
    SELECT MANV INTO MA_BS FROM NHANVIEN WHERE CMND = USERNAME;
    RETURN 'MABS =' || MA_BS;
  ELSE 
    RETURN '1=1';
  END IF;
END;



BEGIN dbms_rls.add_policy 
(object_schema =>'QLTT',
object_name => 'HSBA',
policy_name => 'POLICY_BS_XEM_CT_HSBA',
function_schema => 'QLTT',
policy_function => 'BS_XEM_CT_HSBA',
statement_types => 'SELECT');
END;


