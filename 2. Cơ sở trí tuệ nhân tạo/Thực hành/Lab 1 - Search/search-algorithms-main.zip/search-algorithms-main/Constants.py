grey = (100, 100, 100)  # color for node in the path
white = (255, 255, 255)  # color for text
yellow = (200, 200, 0)  # current node
red = (200, 0, 0)  # discovered node
blue = (30, 144, 255)  # completed node (item of closed set)
purple = (138, 43, 226) # goal
orange = (255,165,0) # start
green = (54, 179, 72) # path

RES = WIDTH, HEIGHT = 750, 540
TILE = 30
cols, rows = WIDTH // TILE, HEIGHT // TILE
