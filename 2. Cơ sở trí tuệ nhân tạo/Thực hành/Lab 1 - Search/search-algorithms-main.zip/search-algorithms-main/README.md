# Project 1: Search Algorithms
Artificial Intelligence at HCMUS

Search Algorithms include: DFS, BFS, UCS and A*
