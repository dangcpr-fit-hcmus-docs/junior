# Project 2: Logic
Artificial Intelligence at HCMUS

Logic include: Propositional Logic, Predicate Logic, Resolution Algorithm
